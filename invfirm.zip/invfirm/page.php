<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>DIGITRADS - Hyip Investment</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            href="https://fonts.googleapis.com/css2?family=IBM+Plex+Serif:wght@100;200;300;400;500;600;700&family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap"
            rel="stylesheet">

        <!-- Icon Font Stylesheet -->
        <link
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
            rel="stylesheet">

        <!-- boot icon -->
        <link rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
        <!-- Libraries Stylesheet -->
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css"
            rel="stylesheet">

        <!-- Customized Bootstrap 5 Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <div class="bg-dark p-0">
            <!-- Spinner Start -->
            <div id="spinner"
                class="show bg-white position-fixed translate-middle w-100
                vh-100 top-50 start-50 d-flex align-items-center
                justify-content-center">
                <div class="spinner-border text-primary" style="width: 3rem;
                    height: 3rem;" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
            <!-- Spinner End -->


            <!-- Navbar & Hero Start -->
            <div class="container-fluid position-relative p-0">
                <nav class="navbar navbar-expand-xl navbar-light px-4 px-lg-5
                    py-3 py-lg-0">
                    <a href="index.php" class="navbar-brand p-0">
                        <!-- <h1><i class="fa fa-comments-dollar text-primary"></i> <span class="text-primary">Profit</span>
                        Machine
                    </h1> -->
                        <img src="logo.png" alt="">
                    </a>
                    <button class="navbar-toggler text-white" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="index.php" class="nav-item nav-link ">HOME</a>
                            <a href="about.php" class="nav-item nav-link ">ABOUT</a>
                            <div id="dropdownMenu" class="dropdown1">
                                <a href="#" class="drop-nav dropdown-toggle active"
                                    role="button" id="dropdownMenuButton1"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    PLAN
                                </a>
                                <ul class="dropdown-menu"
                                    aria-labelledby="dropdownMenuButton1">
                                    <li><a class="dropdown-item " href="page.php">MISSION & VISION</a></li>
                                </ul>
                            </div>
                            <a href="plan.php" class="nav-item nav-link">PAGES</a>
                            <a href="blog.php" class="nav-item nav-link">BLOG</a>
                            <a href="contact.php" class="nav-item nav-link">CONTACT</a>
                            <a href="#contact" class="nav-item nav-link"><button class="btn btn-primary rounded-pill
                                text-dark px-4 ">INVEST NOW</button></a>
                        </div>
                        <!-- <a href="#" class="btn btn-primary rounded-pill
                            text-dark py-2 px-4 ms-lg-5">Register</a>
                        <a href="#" class="btn btn-outline-primary rounded-pill
                            text-white py-2 px-4 ms-lg-2">Login</a> -->
                    </div>
                </nav>
               

                <div class="container-flex bg-dark hero-header"
                    style="background: url(img/bred.png); background-size: cover; background-repeat: no-repeat;">
                    <div class="container">
                        <div class="row vh-100 d-flex align-items-center
                            pt-lg-5">
                            <div class="col-lg-7 text-center text-lg-start">
                                <div class="container">
                                    <h1 class="hero-title mb-4">OUR COMPANY MISSION & VISION</h1>
                                    <ol class="breadcrumb d-flex">
                                      <li class="breadcrumb-item">
                                        <a href="index.html">Home</a>
                                      </li>
                                      <li class="breadcrumb-item active">MISSION & VISION</li>
                                    </ol>
                                  </div>
                            </div>
                            <div class="col-lg-5 text-center text-lg-end">
                                <img class="img-fluid animated zoomIn float-ani"
                                    src="img/thumb2.png" alt="hero image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Navbar & Hero End -->


            <!-- About Start -->
            <div class="container-fluid py-6" id="about">
                <div class="">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow zoomIn p-5" data-wow-delay="0.1s">
                            <img class="img-fluid float-ani" src="img/mission.png">
                        </div>
                        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                            <h2 class="mb-4 text-white">Our Mission</h2>
                            <h5 class="mb-4 text-muted secondary-font">Establish You With The Help Of DigiTrands</h5>
                            <p>At Digitrands, we offer comprehensive trading courses for novice and experienced investors and traders who want to learn the professional trading techniques and make a bright career in the stock market.</p>
                            <div class="row g-3 mb-4">
                                <div class="col-md-6 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#a6ec91, #115703);">
                                        <img src="img/1.png">
                                        <!-- <i class="fa fa-chart-bar text-dark"></i> -->
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">Low investment</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#e69090, #7a1710);">
                                        <img src="img/2.png">
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">Over view on service</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 d-flex mt-3">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#b47fdf, #9531d8);">
                                        <img src="img/3.png">
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">24/7 customer support</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 d-flex mt-3">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#6b4df1, #0c1cc7);">
                                        <img src="img/4.png">
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">Life time membership</h6>
                                    </div>
                                </div>
                            </div>
                            <!-- <a class="btn btn-primary rounded-pill py-2 px-5 fs-5 fw-bold text-dark mt-2 secondary-font"
                                href="">Read
                                More</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- About End -->


            <!-- About Start -->
            <div class="container-fluid py-6" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <h1 class="mb-4 text-white">Our Vision</h1>
                            <h5 class="mb-4 text-muted secondary-font">Makes You Able To Establish By Yourself Within The Digitrands</h6>
                                <p>We strive to help you meet your financial goals with a comprehensive curriculum. Our Training are designed to cover a spectrum of trading styles and asset classes including Intraday Day, Swing Trading, Position Trading, and Investment Theory for Stocks, Futures, Options, Commodities, Currencies and Forex.</p>
                            <div class="row g-3 mb-4">
                                <div class="col-md-6 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#a6ec91, #115703);">
                                        <img src="img/1.png">
                                        <!-- <i class="fa fa-chart-bar text-dark"></i> -->
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">Low investment</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#e69090, #7a1710);">
                                        <img src="img/2.png">
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">Over view on service</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 d-flex mt-3">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#b47fdf, #9531d8);">
                                        <img src="img/3.png">
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">24/7 customer support</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 d-flex mt-3">
                                    <div class="flex-shrink-0 btn-lg-square rounded-circle" style="background: linear-gradient(#6b4df1, #0c1cc7);">
                                        <img src="img/4.png">
                                    </div>
                                    <div class="ms-2">
                                        <h6 class="mt-2 text-white secondary-font">Life time membership</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 wow zoomIn p-5"
                            data-wow-delay="0.1s">
                            <img class="img-fluid float-ani"
                                src="img/howto.png">
                        </div>
                    </div>
                </div>
            </div>
            <!-- About End -->


            <!-- Client Start -->
            <div class="container-fluid spcial-bg-color py-5 wow fadeInUp"
                data-wow-delay="0.1s">
                <div class="container">
                    <div class="owl-carousel client-carousel">
                        <a href="#"><img class="img-fluid" src="img/logo-1.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-2.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-3.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-4.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-5.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-6.png"
                                alt=""></a>
                    </div>
                </div>
            </div>
            <!-- Client End -->

            

            <!-- Stats start -->

            <div class="container-fluid spcial-bg-color py-5" id="stats">
                <div class="container py-5">
                    <!-- <center class="wow fadeInDown">
                    <div class="d-inline-block border rounded-pill text-primary px-4 mb-3 fs-5 text-center">Stats</div>
                </center> -->
                    <!-- <h2 class="mb-4 text-white text-center">Our Site <span class="text-primary">Statistics</span></h2> -->
                    <div class="row mt-4">
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.3s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <img src="img/item1.png">
                                </div>
                                    <p class="d-flex align-items-center justify-content-center">Top Investor</p>
                                    <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">$40,000.00</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Invested
                                    in pitches</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <img src="img/item2.png">
                                </div>
                                    <p class="d-flex align-items-center justify-content-center">Top Investor</p>
                                    <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">$40,000.00</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Registered
                                    Members</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.5s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <img src="img/item3.png">
                                </div>
                                    <p class="d-flex align-items-center justify-content-center">Top Investor</p>
                                    <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">$40,000.00</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Average
                                    Investment</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.7s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <img src="img/item4.png">
                                </div>
                                    <p class="d-flex align-items-center justify-content-center">Top Investor</p>
                                    <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">$40,000.00</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Total
                                    Investment Plan</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats end -->
            
            <!-- Testimonial Start -->
            <div class="container-fluid py-6" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow zoomInp-5 hide"
                            data-wow-delay="0.1s">
                            <img class="img-fluid float-ani"
                                src="img/testimo.png">
                        </div>
                        <div class="col-lg-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="d-inline-block border rounded-pill
                                text-primary px-4 mb-3 fs-5">OUR HAPPLY CLIENT</div>
                            <h1 class="mb-4 text-white">Discover Our Happy
                                Client Feedback</h1>
                            <p class="mb-4 text-muted secondary-font">We see our customers as invited guests to a party, and we are the hosts. It's Our job every Every day to make every important aspect of the customer experience a little bit better.</p>
                            <div class="owl-carousel testimonial-carousel wow
                                fadeInUp"
                                data-wow-delay="0.1s">
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">It comes down to how the brand - and the digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-1.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1 text-white">Justin
                                                Baiber</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">The digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome Thanks so much!</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-2.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1">Client Name</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">It comes down to how the brand - and the digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-3.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1">Client Name</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">The digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome Thanks so much!</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-4.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1">Client Name</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- Testimonial End -->
        
            
        <!-- GG coin Start -->

            <div class="container-fluid py-6" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow zoomInp-5"
                            data-wow-delay="0.1s">
                            <div class="features-left">
                                <h2 class="mb-4">Our Main Features</h2>
                                <p class="secondary-font">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eius
                                    nisi
                                    laudantium autem
                                    recusandae accusamus sapiente cumque, pariatur ab, quod, quaerat harum dignissimos
                                    dolores
                                    velit asperiores saepe a illum maxime! Inventore?
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="owl-carousel testimonial-carousel wow
                                fadeInUp"
                                data-wow-delay="0.1s">
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/icon2.png">
                                        <div class="ps-3">
                                            <h6 class="mb-1 text-white">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/icon1.png">
                                        <div class="ps-3">
                                            <h6 class="mb-1">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/bit.webp">
                                        <div class="ps-3">
                                            <h6 class="mb-1">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/icon3.png">
                                        <div class="ps-3">
                                            <h6 class="mb-1">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- GG coin end -->
            <!-- Footer Start -->
            <div class="container-fluid foot text-light footer pt-5 wow
                fadeIn" data-wow-delay="0.1s"
                style="margin-top: 6rem;">
                <div class="container py-5">
                    <div class="row g-5">
                        <div class="col-md-6 col-lg-6">
                            <h5 class="text-light mb-4">Know About Us</h5>
                            <p>We Digitrads offer services of investment trust management of the funds provided by third party investors aiming at obtaining profit by both investors and companies.</p>                            <h5 class="text-light mb-4">Newsletter</h5>
                            <!-- <p>Lorem ipsum dolor sit amet elit. Phasellus nec
                                pretium mi. Curabitur facilisis ornare velit
                                non vulpu</p> -->
                            <div class="position-relative w-10 mt-3">
                                <input class="form-control bg-primary border-0 rounded-pill w-100 ps-4 pe-5" type="email" name="email" id="email" placeholder="Your Email" style="height: 40px;">
                                <button type="button" class="btn shadow-none position-absolute top-0 end-0 mt-1 me-2"><i class="fa fa-paper-plane text-dark fs-4"></i></button>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3 text-center text-md-end">
                            <h5 class="text-light mb-4">Get In Touch</h5>
                            <p><i class="fa fa-map-marker-alt me-3"></i>Sector-2-XXXX, India</p>
                            <p><i class="fa fa-phone-alt me-3"></i>+91 XXXXXXXXXX</p>
                            <p><i class="fa fa-envelope me-3"></i>support@digitrads.com</p>
                            <div class="d-flex pt-2 justify-content-center
                                justify-content-md-end">
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-youtube"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-3 text-center text-lg-end">
                            <h5 class="text-light mb-4">Quick Link</h5>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">About Us</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">Contact Us</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">Privacy Policy</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">Terms & Condition</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">FAQs</a>
                        </div>

                    </div>
                </div>
                <div class="container">
                    <div class="copyright">
                        <div class="row">
                            <div class="col-md-6 text-center text-md-start mb-3
                                mb-md-0">
                                &copy; 2022 <a class="border-bottom" href="#">digitrads</a>,
                                All Right Reserved,<br>
                                Designed with ❤️ By <a class="border-bottom"
                                    target="_blank"
                                    href="https://algorizon.com/">Algorizon
                                    Technology</a>
                                <!-- <a class="border-bottom" target="_blank"
                                    href="https://amarkarthik.in.com">Amar
                                    Karthik</a> -->
                            </div>
                            <div class="col-md-6 text-center text-md-end">
                                <div class="footer-menu mt-2">
                                    <a href="">Home</a>
                                    <a href="">Cookies</a>
                                    <a href="">Help</a>
                                    <a href="">FAQs</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->


            <!-- Back to Top -->
            <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top
                text-dark"><i
                    class="fa fa-arrow-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>

</html>
