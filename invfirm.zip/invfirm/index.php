<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>DIGITRADS - Hyip Investment</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            href="https://fonts.googleapis.com/css2?family=IBM+Plex+Serif:wght@100;200;300;400;500;600;700&family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap"
            rel="stylesheet">

        <!-- Icon Font Stylesheet -->
        <link
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
            rel="stylesheet">

        <!-- boot icon -->
        <link rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
        <!-- Libraries Stylesheet -->
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css"
            rel="stylesheet">

        <!-- Customized Bootstrap 5 Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <div class="bg-dark p-0">
            <!-- Spinner Start -->
            <div id="spinner"
                class="show bg-white position-fixed translate-middle w-100
                vh-100 top-50 start-50 d-flex align-items-center
                justify-content-center">
                <div class="spinner-border text-primary" style="width: 3rem;
                    height: 3rem;" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
            <!-- Spinner End -->


            <!-- Navbar & Hero Start -->
            <div class="container-fluid position-relative p-0">
                <nav class="navbar navbar-expand-xl navbar-light px-4 px-lg-5
                    py-3 py-lg-0">
                    <a href="index.php" class="navbar-brand p-0">
                        <!-- <h1><i class="fa fa-comments-dollar text-primary"></i> <span class="text-primary">Profit</span>
                        Machine
                    </h1> -->
                        <img src="img/logo.png" alt="">
                    </a>
                    <button class="navbar-toggler text-white" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="index.php" class="nav-item nav-link active">HOME</a>
                            <a href="about.php" class="nav-item nav-link">ABOUT</a>
                            <div id="dropdownMenu" class="dropdown1">
                                <a href="#" class="drop-nav dropdown-toggle"
                                    role="button" id="dropdownMenuButton1"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    PLAN
                                </a>
                                <ul class="dropdown-menu"
                                    aria-labelledby="dropdownMenuButton1">
                                    <li><a class="dropdown-item " href="page.php">MISSION & VISION</a></li>
                                </ul>
                            </div>
                            <a href="plan.php" class="nav-item nav-link">PAGES</a>
                            <a href="blog.php" class="nav-item nav-link">BLOG</a>
                            <a href="contact.php" class="nav-item nav-link">CONTACT</a>
                            <a href="#contact" class="nav-item nav-link"><button class="btn btn-primary rounded-pill
                                text-dark px-4 ">INVEST NOW</button></a>
                        </div>
                        <!-- <a href="#" class="btn btn-primary rounded-pill
                            text-dark py-2 px-4 ms-lg-5">Register</a>
                        <a href="#" class="btn btn-outline-primary rounded-pill
                            text-white py-2 px-4 ms-lg-2">Login</a> -->
                    </div>
                </nav>

                <div class="container-flex bg-dark hero-header"
                    style="background: url(img/bg.png); background-size: cover; background-repeat: no-repeat;">
                    <div class="container">
                        <div class="row vh-100 d-flex align-items-center
                            pt-lg-5">
                            <div class="col-lg-7 text-center text-lg-start">
                                <h1 class="text-white mb-4 animated zoomIn
                                    display-5">Welcome To Digitrads<span
                                        class="text-primary hide">FINENCIAL SOLUTIONS</span>
                                </h1>
                                <p class="text-white pb-3 animated zoomIn
                                    secondary-font">LEARN ,CREATE WEALTH AND INSPIRE PEOPLE! We are Providing Stock Market Education.</p>
                                <a href=""
                                    class="btn btn-outline-success rounded-pill
                                    border-2 py-3 px-5 animated slideInRight
                                    secondary-font fs-5">Get
                                    Started Now</a>
                            </div>
                            <div class="col-lg-5 text-center text-lg-end">
                                <img class="img-fluid animated zoomIn float-ani"
                                    src="img/thumb.png" alt="hero image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Navbar & Hero End -->




            <!-- Features Start -->
            <div class="container-fluid bg-white-50 py-6 features">
                <div class="container">
                    <div class="row g-5">
                        <div class="col-lg-5 wow fadeInUp d-flex
                            align-items-center" data-wow-delay="0.1s">

                            <div class="features-left">
                                <div class="services d-inline-block rounded-pill
                                    text-dark px-4 mb-3"><h3>HOW TO DO IT</h3></div>
                                <h2 class="mb-4">Follow  3 Easy Step</h2>
                                <p class="secondary-font">Follow this Steps To Get Started With Us To make Future Secure.</p>
                                <a class="btn btn-dark rounded-pill fs-5 fw-bold
                                    py-2 px-5 mt-2 secondary-font" href="#">Get
                                    started now!</a>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="row g-5">
                                <div class="col-sm-5 wow fadeIn each-feature p-3
                                    text-center" data-wow-delay="0.1s" style="background: linear-gradient(#e66465, #9198e5);">
                                    <div class="px-3">
                                        <div
                                            class="d-flex align-items-center
                                            justify-content-center mb-3 bg-dark
                                            rounded-pill p-3">
                                            <i class="fa fa-users fa-2x
                                                text-white me-3"></i>
                                            <h6 class="mb-0 fs-4 fw-bold
                                                text-white">Quick Registration</h6>
                                        </div>
                                        <span class="secondary-font text-dark">Register With Your Phone or Email.</span>
                                    </div>
                                </div>
                                <div class="col-sm-5 wow fadeIn each-feature p-3
                                    text-center" data-wow-delay="0.1s" style="background: linear-gradient(#e66465, #9198e5);">
                                    <div class="px-3">
                                        <div
                                            class="d-flex align-items-center
                                            justify-content-center mb-3 bg-dark
                                            rounded-pill p-3">

                                            <i class="fa fa-headset fa-2x
                                                text-white me-3"></i>

                                            <h6 class="mb-0 fs-4 fw-bold
                                                text-white">Make An Invest</h6>
                                        </div>
                                        <span class="secondary-font text-dark">Make an Invest That You Can And wait For The Huge Outcome.</span>
                                    </div>
                                </div>
                                <div class="col-sm-5 wow fadeIn each-feature p-3
                                    text-center" data-wow-delay="0.1s" style="background: linear-gradient(#e66465, #9198e5);">
                                    <div class="px-3">
                                        <div
                                            class="d-flex align-items-center
                                            justify-content-center mb-3 bg-dark
                                            rounded-pill p-3">

                                            <i class="fa fa-globe-asia fa-2x
                                                text-white me-3"></i>

                                            <h6 class="mb-0 fs-4 fw-bold
                                                text-white">Get Your Profit</h6>
                                        </div>
                                        <span class="secondary-font text-dark">Once The wait is over Get Your profit And Transfer to Your Bank Acount.</span>
                                    </div>
                                </div>
                                <!-- <div class="col-sm-6 wow fadeIn each-feature p-3 text-center" data-wow-delay="0.1s">
                                <div class="px-3">
                                    <div
                                        class="d-flex align-items-center justify-content-center mb-3 bg-dark rounded-pill p-3">

                                        <i class="fa fa-chart-line fa-2x text-white me-3"></i>

                                        <h6 class="mb-0 fs-4 fw-bold text-white">Profitable Program</h6>
                                    </div>
                                    <span class="secondary-font text-dark">Lorem ipsum dolor sit amet,
                                        consectetur
                                        adipisicing elit.
                                        Totam cumque.</span>
                                </div>
                            </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Features End -->



            <!-- Client Start -->
            <div class="container-fluid spcial-bg-color py-5 wow fadeInUp"
                data-wow-delay="0.1s">
                <div class="container">
                    <div class="owl-carousel client-carousel">
                        <a href="#"><img class="img-fluid" src="img/logo-1.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-2.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-3.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-4.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-5.png"
                                alt=""></a>
                        <a href="#"><img class="img-fluid" src="img/logo-6.png"
                                alt=""></a>
                    </div>
                </div>
            </div>
            <!-- Client End -->

            <!-- About Start -->
            <div class="container-fluid py-6" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow zoomIn p-5"
                            data-wow-delay="0.1s">
                            <img class="img-fluid float-ani"
                                src="img/howto.png">
                        </div>
                        <div class="col-lg-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="d-inline-block border rounded-pill
                                text-primary px-4 mb-3 fs-5">AWESOME HYIP
                                FEATURES</div>
                            <h1 class="mb-4 text-white">Our Best Hyip Features</h1>
                            <p class="mb-4 text-muted secondary-font">Trusted associate in the high-yield investment program space and the best HYIP monitoring service and More.</p>
                            <div class="row g-3 mb-4">
                                <div class="col-12 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square
                                        rounded-circle bg-primary">
                                        <i class="fa fa-chart-bar text-dark"></i>
                                    </div>
                                    <div class="ms-2">
                                        <h4 class="mt-2 text-white
                                            secondary-font">Account Management</h4>
                                        <p>Provide customers with service, support and improvement opportunities to increase their consumption of a product service and More.</p>
                                    </div>
                                </div>
                                <div class="col-12 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square
                                        rounded-circle bg-primary">
                                        <i class="fa fa-user-clock text-dark"></i>
                                    </div>
                                    <div class="ms-2">
                                        <h4 class="mt-2 text-white
                                            secondary-font">Make security
                                            management</h4>
                                        <p>Offer all aspects of protecting an organization's assets computers, people, buildings, and other assets – against risk.</p>
                                    </div>
                                </div>
                                <div class="col-12 d-flex">
                                    <div class="flex-shrink-0 btn-lg-square
                                        rounded-circle bg-primary">
                                        <i class="fa fa-check text-dark"></i>
                                    </div>
                                    <div class="ms-2">
                                        <h4 class="mt-2 text-white
                                            secondary-font">Profit Management</h4>
                                        <p>Handles all The data such as the name, department, office location, managers etc Related To The User.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- <a class="btn btn-primary rounded-pill py-2 px-5 fs-5 fw-bold text-dark mt-2 secondary-font"
                            href="">Read
                            More</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- About End -->

            <!-- Pricing starts -->

            <div class="container-fluid pricing py-5" id="plans">
                <div class="container py-5">
                    <center class="wow fadeInDown">
                        <div class="d-inline-block border rounded-pill
                            text-primary px-4 mb-3 fs-5 text-center">CHOOSE YOUR
                            PLAN</div>
                    </center>
                    <h2 class="mb-4 text-light text-center">Best Investment
                        Platform For Your Profit</h2>

                    <div class="row mt-5">
                        <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="pricing-table-3 basic">
                                <div class="pricing-table-header">
                                    <h4 class="text-light">600%</h4>
                                </div>
                                <div class="price"><i class="text-dark fa
                                        fa-money-bill-wave fa-3x"></i></div>
                                <div class="pricing-body mt-4">
                                    <ul class="pricing-table-ul">
                                        <li><h3>04 Days</h3></li>
                                        <li>Minimum : $30.00</li>
                                        <li>Maximum : $1500.00</li>
                                        <li>Down to 5% for daily</li>
                                    </ul><a href="#" class="view-more
                                        rounded-pill">Invest Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp"
                            data-wow-delay="0.3s">
                            <div class="pricing-table-3 basic">
                                <div class="pricing-table-header">
                                    <h4 class="text-light"><strong>700%</strong></h4>
                                </div>
                                <div class="price"><i class="text-dark fa
                                        fa-chart-bar fa-3x"></i></div>
                                <div class="pricing-body mt-4">
                                    <ul class="pricing-table-ul">
                                        <li><h3>10 Days</h3></li>
                                        <li>Minimum : $30.00</li>
                                        <li>Maximum : $1500.00</li>
                                        <li>Down to 5% for daily</li>
                                    </ul><a href="#" class="view-more
                                        rounded-pill">Invest Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp"
                            data-wow-delay="0.5s">
                            <div class="pricing-table-3 basic">
                                <div class="pricing-table-header">
                                    <h4 class="text-light"><strong>800%</strong></h4>
                                </div>
                                <div class="price"><i class="text-dark fa
                                        fa-cash-register fa-3x"></i></div>
                                <div class="pricing-body mt-4">
                                    <ul class="pricing-table-ul">
                                        <li><h3>07 Days</h3></li>
                                        <li>Minimum : $30.00</li>
                                        <li>Maximum : $1500.00</li>
                                        <li>Down to 5% for daily</li>
                                    </ul><a href="#" class="view-more
                                        rounded-pill">Invest Now</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp"
                            data-wow-delay="0.7s">
                            <div class="pricing-table-3 basic">
                                <div class="pricing-table-header">
                                    <h4 class="text-light"><strong>1200%</strong></h4>
                                </div>
                                <div class="price"><i class="text-dark fa
                                        fa-calendar-check fa-3x"></i></div>
                                <div class="pricing-body mt-4">
                                    <ul class="pricing-table-ul">
                                        <li><h3>15 Days</h3></li>
                                        <li>Minimum : $30.00</li>
                                        <li>Maximum : $1500.00</li>
                                        <li>Down to 5% for daily</li>
                                    </ul><a href="#" class="view-more
                                        rounded-pill">Invest Now</a>
                                </div>
                            </div>
                        </div>

                        <!-- <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="pricing-table-3 basic">
                            <div class="pricing-table-header">
                                <h4 class="text-white"><strong>Bronze Plan</strong></h4>
                            </div>
                            <div class="price"><i class="text-dark fa fa-money-bill-wave fa-3x"></i></div>
                            <div class="pricing-body mt-4">
                                <ul class="pricing-table-ul">
                                    <li>Up to 20% hourly</li>
                                    <li>Principal return everyday</li>
                                    <li>Down to 5% for daily</li>
                                    <li>Registered company</li>
                                    <li>Get started now</li>
                                </ul><a href="#" class="view-more rounded-pill">Buy now!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="pricing-table-3 basic">
                            <div class="pricing-table-header">
                                <h4 class="text-white"><strong>Silver Plan</strong></h4>
                            </div>
                            <div class="price"><i class="text-dark fa fa-chart-bar fa-3x"></i></div>
                            <div class="pricing-body mt-4">
                                <ul class="pricing-table-ul">
                                    <li>Up to 20% hourly</li>
                                    <li>Principal return everyday</li>
                                    <li>Down to 5% for daily</li>
                                    <li>Registered company</li>
                                    <li>Get started now</li>
                                </ul><a href="#" class="view-more rounded-pill">Buy now!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="pricing-table-3 basic">
                            <div class="pricing-table-header">
                                <h4 class="text-white"><strong>Gold Plan</strong></h4>
                            </div>
                            <div class="price"><i class="text-dark fa fa-cash-register fa-3x"></i></div>
                            <div class="pricing-body mt-4">
                                <ul class="pricing-table-ul">
                                    <li>Up to 20% hourly</li>
                                    <li>Principal return everyday</li>
                                    <li>Down to 5% for daily</li>
                                    <li>Registered company</li>
                                    <li>Get started now</li>
                                </ul><a href="#" class="view-more rounded-pill">Buy now!</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="pricing-table-3 basic">
                            <div class="pricing-table-header">
                                <h4 class="text-white"><strong>Platinum Plan</strong></h4>
                            </div>
                            <div class="price"><i class="text-dark fa fa-calendar-check fa-3x"></i></div>
                            <div class="pricing-body mt-4">
                                <ul class="pricing-table-ul">
                                    <li>Up to 20% hourly</li>
                                    <li>Principal return everyday</li>
                                    <li>Down to 5% for daily</li>
                                    <li>Registered company</li>
                                    <li>Get started now</li>
                                </ul><a href="#" class="view-more rounded-pill">Buy now!</a>
                            </div>
                        </div>
                    </div> -->
                    </div>
                    <a class="btn btn-primary rounded-pill py-2 px-5 fs-5
                        fw-bold text-dark mt-5 secondary-font"
                        href="">Discover More..</a>
                </div>

            </div>

            <!-- Pricing ends -->

            <!-- Stats start -->

            <div class="container-fluid spcial-bg-color py-5" id="stats">
                <div class="container py-5">
                    <!-- <center class="wow fadeInDown">
                    <div class="d-inline-block border rounded-pill text-primary px-4 mb-3 fs-5 text-center">Stats</div>
                </center> -->
                    <!-- <h2 class="mb-4 text-white text-center">Our Site <span class="text-primary">Statistics</span></h2> -->
                    <div class="row mt-4">
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.3s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <i class="fa fa-money-bill-wave"></i>
                                </div>
                                <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">$557</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Invested
                                    in pitches</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <i class="fa fa-users"></i>
                                </div>
                                <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">254k</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Registered
                                    Members</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.5s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <i class="fa fa-dollar-sign"></i>
                                </div>
                                <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">$774k</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Average
                                    Investment</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex
                            justify-content-center wow fadeInUp"
                            data-wow-delay="0.7s">
                            <div class="each-stat">
                                <div
                                    class="btn btn-outline-primary d-flex
                                    align-items-center justify-content-center
                                    mx-auto">
                                    <i class="fa fa-users"></i>
                                </div>
                                <p class="text-center secondary-font
                                    text-primary fs-3 fw-bold">7740</p>
                                <p class="text-white fs-4 text-center mt-2 m-0">Total
                                    Investment Plan</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats end -->




            <div class="container-fluid bg-white-50 features">
                <div class="container">
                    <div class="row g-5">
                        <div class="col-lg-6 col-md-12 wow fadeInUp d-flex
                            align-items-center" data-wow-delay="0.1s">
                            <div class="features-left hide">
                                <img src="img/why.png">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row g-5">
                                <div class="d-inline-block border rounded-pill
                                    text-primary fs-5">WHY CHOOSE US</div>
                                <h2 class="text-dark">Why You Should Saty With
                                    Us</h2>
                                <div class="col-md-4 ">
                                    <i class="bi bi-lock icon" style="color: #00baca;"></i>
                                    <ol class="text-center p-0"><b>High Security</b></ol>
                                </div>
                                <div class="col-md-4 pt-3">
                                    <i class="bi bi-robot icon" style="color: #a64dff;"></i>
                                    <ol class="text-center p-0"><b>Live Chat</b></ol>
                                </div>
                                <div class="col-md-4 pt-5">
                                    <i class="bi bi-currency-exchange icon" style="color: #2d52e0;"></i>
                                    <ol class="text-center p-0"><b>High Security</b></ol>
                                </div>
                                <div class="col-md-4 ">
                                    <i class="bi bi-speedometer2 icon" style="color: #43a8ff;"></i>
                                    <ol class="text-center p-0"><b>High Security</b></ol>
                                </div>
                                <div class="col-md-4 pt-3">
                                    <i class="bi bi-lock icon" style="color: #00baca;"></i>
                                    <ol class="text-center p-0"><b>High Security</b></ol>
                                </div>
                                <div class="col-md-4 pt-5">
                                    <i class="bi bi-lock icon" style="color: #f5a45b;"></i>
                                    <ol class="text-center p-0"><b>High Security</b></ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Testimonial Start -->
            <div class="container-fluid py-6" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow zoomInp-5 hide"
                            data-wow-delay="0.1s">
                            <img class="img-fluid float-ani"
                                src="img/testimo.png">
                        </div>
                        <div class="col-lg-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="d-inline-block border rounded-pill
                                text-primary px-4 mb-3 fs-5">OUR HAPPLY CLIENT</div>
                            <h1 class="mb-4 text-white">Discover Our Happy
                                Client Feedback</h1>
                            <p class="mb-4 text-muted secondary-font">We see our customers as invited guests to a party, and we are the hosts. It's Our job every Every day to make every important aspect of the customer experience a little bit better.</p>
                            <div class="owl-carousel testimonial-carousel wow
                                fadeInUp"
                                data-wow-delay="0.1s">
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">It comes down to how the brand - and the digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-1.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1 text-white">Justin
                                                Baiber</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">The digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome Thanks so much!</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-2.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1">Client Name</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">It comes down to how the brand - and the digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-3.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1">Client Name</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <i class="fa fa-quote-left fa-2x
                                        text-primary mb-3"></i>
                                    <p class="secondary-font">The digitrand help customers 
                                        to invest into interesting fact that comes with a great Outcome Thanks so much!</p>
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/testimonial-4.jpg">
                                        <div class="ps-3">
                                            <h6 class="mb-1">Client Name</h6>
                                            <small>Profession</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Testimonial End -->
            <!-- blog start -->
            <div class="container">
                <div class="cont border rounded-pill
                    text-primary px-4 mb-3 fs-5">DIGITRADS INVESTMENT BLOG POST</div>
                <h1 class="mb-4 text-white text-center">Best Comunity Platform<br>For
                    Investment</h1>
                <div class="card-group">
                    <div class="card m-3">
                        <img src="img/b1.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h4 class="card-title">INVEST NOW TO REACH THE PICK POINT</h4>
                            <p class="card-text">This is a wider card with
                                supporting text below as a natural lead-in to
                                additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><a href="" class="">Read More..</a></p>
                        </div>
                    </div>
                    <div class="card m-3">
                        <img src="img/b2.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h4 class="card-title">INVEST ONLINE WITHDRAW ONLINE</h4>
                            <p class="card-text">This is a wider card with
                                supporting text below as a natural lead-in to
                                additional content. This card has even longer
                                content than the first to show that equal height
                                action.</p>
                                <p class="card-text"><a href="" class="">Read More..</a></p>
                        </div>
                    </div>
                    <div class="card m-3">
                        <img src="img/b3.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h4 class="card-title">GROW WITH YOUR MOBILE DEVICE</h4>
                            <p class="card-text">This is a wider card with
                                supporting text below as a natural lead-in to
                                additional content. This card has even longer
                                content than the first to show that equal height
                                action.</p>
                                <p class="card-text"><a href="" class="">Read More..</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- blog end -->
               <!-- GG coin Start -->

            <div class="container-fluid py-6" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 wow zoomInp-5"
                            data-wow-delay="0.1s">
                            <div class="features-left">
                                <h2 class="mb-4">Our Main Features</h2>
                                <p class="secondary-font">We offer comprehensive trading courses for novice and experienced 
                                    investors and traders who want to learn the professional trading techniques and make a bright career in the stock market.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6 wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="owl-carousel testimonial-carousel wow
                                fadeInUp"
                                data-wow-delay="0.1s">
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/icon2.png">
                                        <div class="ps-3">
                                            <h6 class="mb-1 text-white">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/icon1.png">
                                        <div class="ps-3">
                                            <h6 class="mb-1">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/bit.webp">
                                        <div class="ps-3">
                                            <h6 class="mb-1">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item rounded p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid flex-shrink-0
                                            rounded-circle"
                                            src="img/icon3.png">
                                        <div class="ps-3">
                                            <h6 class="mb-1">BIT-COIN</h6>
                                            <small>XXXXXXX</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- GG coin end -->
            <!-- Footer Start -->
            <div class="container-fluid foot text-light footer pt-5 wow
                fadeIn" data-wow-delay="0.1s"
                style="margin-top: 6rem;">
                <div class="container py-5">
                    <div class="row g-5">
                        <div class="col-md-6 col-lg-6">
                            <h5 class="text-light mb-4">Know About Us</h5>
                            <p>We Digitrads offer services of investment trust management of the funds provided by third party investors aiming at obtaining profit by both investors and companies.</p>                            <h5 class="text-light mb-4">Newsletter</h5>
                            <!-- <p>Lorem ipsum dolor sit amet elit. Phasellus nec
                                pretium mi. Curabitur facilisis ornare velit
                                non vulpu</p> -->
                            <div class="position-relative w-10 mt-3">
                                <input class="form-control bg-primary border-0 rounded-pill w-100 ps-4 pe-5" type="email" name="email" id="email" placeholder="Your Email" style="height: 40px;">
                                <button type="button" class="btn shadow-none position-absolute top-0 end-0 mt-1 me-2"><i class="fa fa-paper-plane text-dark fs-4"></i></button>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3 text-center text-md-end">
                            <h5 class="text-light mb-4">Get In Touch</h5>
                            <p><i class="fa fa-map-marker-alt me-3"></i>Sector XXXX-India</p>
                            <p><i class="fa fa-phone-alt me-3"></i>+91 XXXXXXXXXX</p>
                            <p><i class="fa fa-envelope me-3"></i>support@digitrads.com</p>
                            <div class="d-flex pt-2 justify-content-center
                                justify-content-md-end">
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-youtube"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-light btn-social"
                                    href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-3 text-center text-lg-end">
                            <h5 class="text-light mb-4">Quick Link</h5>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">About Us</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">Contact Us</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">Privacy Policy</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">Terms & Condition</a>
                            <a class="btn btn-link text-center text-lg-end"
                                href="">FAQs</a>
                        </div>

                    </div>
                </div>
                <div class="container">
                    <div class="copyright">
                        <div class="row">
                            <div class="col-md-6 text-center text-md-start mb-3
                                mb-md-0">
                                &copy; 2022 <a class="border-bottom" href="#">digitrads.com</a>,
                                All Right Reserved,<br>
                                Designed with ❤️ By <a class="border-bottom"
                                    target="_blank"
                                    href="https://algorizon.com/">Algorizon
                                    Technology</a>
                                <!-- <a class="border-bottom" target="_blank"
                                    href="https://amarkarthik.in.com">Amar
                                    Karthik</a> -->
                            </div>
                            <div class="col-md-6 text-center text-md-end">
                                <div class="footer-menu mt-2">
                                    <a href="">Home</a>
                                    <a href="">Cookies</a>
                                    <a href="">Help</a>
                                    <a href="">FAQs</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->


            <!-- Back to Top -->
            <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top
                text-dark"><i
                    class="fa fa-arrow-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>

</html>
